import express from 'express';
const router = express.Router();
import { creatPost, deletePost, getPost, getPosts, updatePost } from '../controller/postController.js';

// get all posts
router.get('/',getPosts)

// get a single post
router.get('/:id',getPost);

// creatr a new post
router.post('/',creatPost);

// update post
router.put('/:id',updatePost);

//delete post
router.delete('/:id',deletePost);

export default router;
