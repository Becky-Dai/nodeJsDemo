import express from 'express';
import path from 'path';
import posts from './routes/posts.js';
const app = express();
const port = process.env.PORT || 8000;
import logger from './middleware/logger.js';
import errorHandler from './middleware/error.js';
import notFound from './middleware/notFound.js';
import {fileURLToPath} from 'url';
// setup static folder 这里的about页面要加.html
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename)

app.use(express.static(path.join(__dirname,'public')));

// app.get('/',(req,res) =>{
//     //res.send('<h1> hello world </h1>');
//     res.sendFile(path.join(__dirname,'public','index.html'));
// });

// app.get('/about',(req,res) =>{
//     //res.send('<h1> hello world </h1>');
//     res.sendFile(path.join(__dirname,'public','about.html'));
// });


// body parser middleware
app.use(express.json());
app.use(express.urlencoded({extended: false}));

app.use(logger);

app.use('/api/posts',posts);

app.use(notFound);

app.use(errorHandler);

app.listen(port,() => console.log(`Server is running on port ${port}`));

