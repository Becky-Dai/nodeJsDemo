let posts = [
    {id:1, title: 'Becky post'},
    {id:2, title: 'Alice post'},
    {id:3, title: 'Ada post'},
]

//@desc get all post 
//@route GET /api/posts
export const getPosts = (req,res,next) => {
    const limit = parseInt(req.query.limit);

    if(!isNaN(limit) && limit >0 ){
        return res.status(200).json(posts.slice(0,limit));
    }
    res.status(200).json(posts);
    
};

//@descn get a single post
//@route get GET/api/posts/:id
export const getPost = (req,res,next) => {
    // console.log(req.params.id);
    const id = parseInt(req.params.id);
    const post =posts.find((post) => post.id === id);

    if (!post){
        const error = new Error(`A post with id: of ${id} is not found`);
        error.status = 404;
        return next(error);
    }
    res.status(200).json(post);
}

//@descn create new post
//@route POST /api/posts/:id
export const creatPost = (req,res,next) =>{
    const newpost ={
        id: posts.length+1,
        title: req.body.title
    };
    if (!newpost.title){
        const error = new Error(`plz include a title`);
        error.status = 400;
        return next(error);
    }
    posts.push(newpost);
    res.status(201).json(posts)
}

//@descn update post
//@route PUT /api/posts/:id
export const updatePost = (req,res,next) => {
    const id = parseInt(req.params.id);
    const post =posts.find((post) => post.id === id);

    if (!post){
        const error = new Error(`A post with id: of ${id} is not found`);
        error.status = 404;
        return next(error);
    };
    post.title = req.body.title;
    res.status(200).json(posts);
}

//@descn delete post
//@route Delete /api/posts/:id
export const deletePost = (req,res,next) => {
    const id = parseInt(req.params.id);
    const post =posts.find((post) => post.id === id);

    if (!post){
        const error = new Error(`A post with id: of ${id} is not found`);
        error.status = 404;
        return next(error);
    };
    posts = posts.filter((post) => post.id !== id);
    res.status(200).json(posts);
}